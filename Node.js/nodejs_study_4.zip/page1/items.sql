INSERT INTO items(id,name) VALUES (1,'じゃがいも');
INSERT INTO items(id,name) VALUES (2,'にんじん');
INSERT INTO items(id,name) VALUES (3,'たまねぎ');