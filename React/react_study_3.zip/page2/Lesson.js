// Reactをインポートしてください
import React from 'react';

// Lessonクラスを定義してください
class Lesson extends React.Component{
  render(){
    return(
      <div className='lesson-card'>
        <div className='lesson-item'>
          <p></p>
          <img />
        </div>
      </div>
      );
  }
}

// Lessonクラスをexportしてください
export default Lesson;
