// Reactをインポートしてください
import React from 'react';

// Appクラスを定義してください
class App extends React.Component{
  render(){
    return (
      <h1>Hello React</h1>
    );
  }
    
  }

// Appクラスをエクスポートしてください

export default App