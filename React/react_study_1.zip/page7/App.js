import React from 'react';

class App extends React.Component {
  render() {
    return (
    	<div>
    	  <h1>こんにちは、にんじゃわんこさん！</h1>
    	  {/* <button>タグ「ひつじ仙人」を追加してください */}
    	  <button>ひつじ仙人</button>
    	  
    	  {/* <button>タグ「にんじゃわんこ」を追加してください */}
    	  <button>にんじゃわんこ</button>
    	  
    	</div>
    );
  }
}

export default App;
