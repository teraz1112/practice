import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
// 以下に指定されたコードを貼り付けてください 
ReactDOM.render(<App />, document.getElementById('root'));