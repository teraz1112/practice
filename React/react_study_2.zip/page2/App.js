import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        {/* h1タグにクラス名を追加してください */}
        <h1 className="title">Hello World</h1>
        
        <p>一緒にReactを学びましょう！</p>
      </div>
    );
  }
}

export default App;
