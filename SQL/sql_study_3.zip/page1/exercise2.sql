SELECT *
FROM players
where goals>14;