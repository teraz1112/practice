SELECT goals
FROM players
where name="ウィル";