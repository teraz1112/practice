-- purchasesテーブルから、「nameカラム」と「priceカラム」のデータを取得してください

select name,price
from purchases;