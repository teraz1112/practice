-- purchasesテーブルから、全てのカラムのデータを取得してください

select *
from purchases;