-- purchasesテーブルから、priceカラムのデータを取得してください

select price
from purchases;