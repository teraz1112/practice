-- purchasesテーブルから、nameカラムのデータを取得してください

select name
from purchases;