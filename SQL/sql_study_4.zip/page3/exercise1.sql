-- studentsテーブルからidカラムの値が7のレコードを削除してください。
delete from students

where id=7;

-- 下記のクエリは消さないでください。
SELECT * FROM students;
