-- studentsテーブルにデータを追加してください。
insert into students (name,course)
values("Kate","Java");

-- 下記のクエリは消さないでください。
select * from students;
