-- studentsテーブルのidカラムの値が6のレコードをnameをJordanに、courseをHTMLに変更してください。
update students
set name="Jordan",course="HTML"
where id=6;

-- 下記のクエリは消さないでください。
SELECT * FROM students WHERE id=6;
