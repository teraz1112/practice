-- priceカラムの平均を取得してください

SELECT avg(price)
FROM purchases;