-- 重複するデータを除いたcharacter_nameカラムのデータを取得してください

SELECT distinct(character_name)
FROM purchases;