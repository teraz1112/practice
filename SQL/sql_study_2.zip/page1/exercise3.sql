-- 重複するデータを除いたnameカラムのデータを取得してください

SELECT distinct(name)
FROM purchases;