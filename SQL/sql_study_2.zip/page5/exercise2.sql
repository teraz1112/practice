-- purchasesテーブルのデータの数を取得してください

SELECT count(*)
FROM purchases;