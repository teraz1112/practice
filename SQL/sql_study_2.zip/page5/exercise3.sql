-- character_nameが「にんじゃわんこ」であるデータの数を取得してください

SELECT count (*)
FROM purchases
WHERE character_name="にんじゃわんこ"
;