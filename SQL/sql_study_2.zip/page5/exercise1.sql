-- purchasesテーブルのnameカラムのデータの数を取得してください

SELECT count(name)
FROM purchases;