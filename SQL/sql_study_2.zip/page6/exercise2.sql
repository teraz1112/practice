-- もっとも小さいpriceカラムの値を取得してください

SELECT min(price)
FROM purchases;