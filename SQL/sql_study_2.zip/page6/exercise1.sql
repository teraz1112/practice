-- もっとも大きいpriceカラムの値を取得してください

SELECT max(price)
FROM purchases;