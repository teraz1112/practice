-- priceカラムのデータの合計を取得してください

SELECT sum(price)
FROM purchases;
