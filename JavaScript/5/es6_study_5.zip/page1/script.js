const dog = new Dog("レオ", 4, "チワワ");
dog.info();

