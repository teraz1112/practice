// "./dogData"(相対パス)を書き換えてください。
import { dog1, dog2 } from "./data/dogData";

console.log("---------");
dog1.info();
console.log("---------");
dog2.info();