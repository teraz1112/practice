// Dogクラスをインポートしてください
import Dog from "./dog";

const dog = new Dog("レオ", 4, "チワワ");
dog.info();
