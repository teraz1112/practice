// 以下を書き換えて、定数dog1, dog2をインポートしてください
import {dog1,dog2} from "./dogData";

// 定数dog1とdog2を出力するように左からコピーして書き換えてください
console.log("---------");
dog1.info();
console.log("---------");
dog2.info();