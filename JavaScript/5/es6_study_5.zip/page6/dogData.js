import Dog from "../class/dog";

const dog1 = new Dog("レオ", 4, "チワワ");
const dog2 = new Dog("ベン", 2, "プードル");

export { dog1, dog2 };