// 定数dogをインポートしてください
import dog from "./dogData";

dog.info();