// 変数numberを定義してください
let number=0;

// 変数numberに1を加えて、その後に変数numberの値を出力してください
number+=1;
console.log(number);


// 上述の2行のコードを4回、貼り付けてください
number+=1;
console.log(number);
number+=1;
console.log(number);
number+=1;
console.log(number);
number+=1;
console.log(number);