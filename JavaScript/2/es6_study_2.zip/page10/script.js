// 定数characterを定義し、指定されたオブジェクトを代入してください
const character={
  name:"にんじゃわんこ",age:14
};

// characterの値を出力してください
console.log(character);
