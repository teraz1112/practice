const animals = ["dog", "cat", "sheep"];

// for文を用いて、配列の値を順にコンソールに出力してください
for(let i=0;i<3;i++){
  console.log(animals[i]);
}
