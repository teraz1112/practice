// for文を用いて、1から100までの数字を出力してください
for(let number=1;number<=100;number++){
  console.log(number);
}
