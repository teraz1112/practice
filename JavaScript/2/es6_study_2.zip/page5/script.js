// 定数animalsに、指定された配列を代入してください
const animals=["dog","cat","sheep"];

// 定数animalsを出力して下さい
console.log(animals);
