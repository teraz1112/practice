// 変数numberを定義してください
let number=1;

// while文を作成してください
while (number<=100){
  console.log(number);
  number+=1;
}
