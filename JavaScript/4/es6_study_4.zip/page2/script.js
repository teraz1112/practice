// Animalクラスを定義してください
class Animal{
  
}
