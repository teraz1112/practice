class Animal {
}

// Animalクラスのインスタンスを定数animalに代入してください
const animal=new Animal();

// 定数animalの値を出力してください
console.log(animal);
