// 関数の引数にnumber1とnumber2を追加してください
const add = (number1,number2) => {
  // number1とnumber2を足した値をコンソールに出力してください
  console.log(number1+number2);
  
};

// 引数に5と7を渡して関数を呼び出してください
add(5,7);
