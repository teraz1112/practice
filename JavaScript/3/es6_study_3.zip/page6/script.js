const half = (number) => {
  // numberを2で割った値を戻り値として返してください
  return number/2;
};

// 定数resultを定義してください
const result=half(130);

// 「130の半分は〇〇です」となるように出力してください
console.log(`130の半分は${result}です`);
