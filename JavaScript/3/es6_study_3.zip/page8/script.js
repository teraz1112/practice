// 関数の外側に定数nameを定義してください
const name="ひつじ仙人";

const introduce = () => {
  // 関数の内側に定数nameを定義してください
  const name="にんじゃわんこ";

  // 定数nameを出力してください
  console.log(name);
  
};

introduce();

// コードを貼り付けて、定数nameを出力してください。
console.log(name);