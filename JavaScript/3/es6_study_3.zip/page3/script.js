// 定数greetにアロー関数を代入してください
const greet=()=>{
  console.log("こんにちは！");
}

// 定数greetを呼び出してください
greet();
