// 定数helloに関数を代入してください
const hello=function(){
  console.log("こんにちは！");
  console.log("私の名前はdaigoです");
}


// 定数helloに代入された関数を呼び出してください
hello();
