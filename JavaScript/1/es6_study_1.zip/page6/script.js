// 変数nameを定義し、「にんじゃわんこ」を代入してください
let name="にんじゃわんこ";

// 変数nameの値を出力してください
console.log(name);
