let number = 7;
console.log(number);

// 変数numberの値に3を加えてください
number+=3;

console.log(number);

// 変数numberの値を2で割ってください
number/=2;


console.log(number);
