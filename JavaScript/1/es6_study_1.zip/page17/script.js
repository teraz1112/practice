const age = 24;

// 指定された条件のif文を作成してください
if(age>=20 && 30>age){
  console.log("私は20代です");
}
