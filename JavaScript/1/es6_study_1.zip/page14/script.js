const password = "ninjawank";

// passwordの値が"ninjawanko"の場合、「ログインに成功しました」と出力してください
if(password=="ninjawanko"){
  console.log("ログインに成功しました");
}



// passwordの値が"ninjawanko"でない場合、「パスワードが間違っています」と出力してください
if(password!="ninjawanko"){
  console.log("パスワードが間違っています");
}

