const n = 2;

switch (n) {
  case 1:
    console.log("大吉です");
    break;

  // nの値が2のcaseを追加してください
  case 2:
    console.log("吉です");
    break;
  
  
  
  // nの値が3のcaseを追加してください
  case 3:
    console.log("小吉です");
    break;
  
  
}
